"""
Pipeline de preprocesamiento robusto con Scikit-Learn.

Dataset: Titanic (OpenML). Objetivo: predecir si un pasajero sobrevivió.

Flujo:
    1. Carga y exploración
    2. Train/Test split (ANTES de cualquier fit -> sin data leakage)
    3. ColumnTransformer (numéricas vs. categóricas)
    4. Pipeline final = preprocesador + LogisticRegression
    5. Entrenamiento y métricas
    6. Persistencia con joblib
    7. Inferencia sobre datos nuevos con .predict()

Uso:
    python src/pipeline.py
"""

from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.datasets import fetch_openml
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "titanic.csv"
MODEL_PATH = ROOT / "models" / "pipeline_titanic.joblib"

RANDOM_STATE = 42
TARGET = "survived"
NUMERIC_FEATURES = ["age", "sibsp", "parch", "fare"]
CATEGORICAL_FEATURES = ["pclass", "sex", "embarked"]


# ---------------------------------------------------------------------------
# 1. Carga y exploración
# ---------------------------------------------------------------------------
def load_data() -> pd.DataFrame:
    """Carga el dataset desde data/ (o lo descarga de OpenML la primera vez)."""
    if DATA_PATH.exists():
        df = pd.read_csv(DATA_PATH)
    else:
        df = fetch_openml("titanic", version=1, as_frame=True).frame
        DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(DATA_PATH, index=False)
    # pclass es un número, pero representa una categoría (1ª, 2ª, 3ª clase)
    df["pclass"] = df["pclass"].astype(str)
    df[TARGET] = df[TARGET].astype(int)
    return df


def explore(df: pd.DataFrame) -> None:
    print("Dimensiones:", df.shape)
    print("\nValores nulos en las columnas usadas:")
    print(df[NUMERIC_FEATURES + CATEGORICAL_FEATURES].isna().sum())
    print("\nDistribución del target:")
    print(df[TARGET].value_counts(normalize=True).round(3))


# ---------------------------------------------------------------------------
# 2-3. Construcción del preprocesador y del pipeline
# ---------------------------------------------------------------------------
def build_pipeline() -> Pipeline:
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])

    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        # handle_unknown='ignore' evita errores con categorías nuevas en inferencia
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("num", numeric_transformer, NUMERIC_FEATURES),
        ("cat", categorical_transformer, CATEGORICAL_FEATURES),
    ])

    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
    ])


def main() -> None:
    df = load_data()
    explore(df)

    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET]

    # 2. Split ANTES de ajustar cualquier transformador (evita data leakage)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )
    print(f"\nTrain: {X_train.shape} | Test: {X_test.shape}")

    # 4. Entrenamiento: el fit del pipeline aprende medianas, modas, medias y
    #    desviaciones SOLO con X_train
    model = build_pipeline()
    model.fit(X_train, y_train)

    # 5. Métricas sobre el conjunto de test
    y_pred = model.predict(X_test)
    print(f"\nAccuracy: {accuracy_score(y_test, y_pred):.3f}")
    print("\nMatriz de confusión:")
    print(confusion_matrix(y_test, y_pred))
    print("\nReporte de clasificación:")
    print(classification_report(y_test, y_pred, target_names=["No sobrevivió", "Sobrevivió"]))

    # 6. Persistencia
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    print(f"Pipeline guardado en: {MODEL_PATH.relative_to(ROOT)}")

    # 7. Inferencia con datos nuevos (incluye nulos y una categoría desconocida)
    loaded = joblib.load(MODEL_PATH)
    nuevos = pd.DataFrame({
        "age":      [29, None, 5],
        "sibsp":    [0, 1, 3],
        "parch":    [0, 0, 2],
        "fare":     [7.25, 80.0, None],
        "pclass":   ["3", "1", "2"],
        "sex":      ["male", "female", "female"],
        "embarked": ["S", None, "X"],   # None = nulo, "X" = categoría nunca vista
    })
    nuevos["prediccion"] = loaded.predict(nuevos)
    nuevos["prob_sobrevivir"] = loaded.predict_proba(nuevos[X.columns])[:, 1].round(3)
    print("\nPredicciones sobre datos nuevos:")
    print(nuevos)


if __name__ == "__main__":
    main()
