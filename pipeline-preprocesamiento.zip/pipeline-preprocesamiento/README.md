# Pipeline de Preprocesamiento Robusto con Scikit-Learn

Práctica de automatización de limpieza y transformación de datos con `Pipeline` y `ColumnTransformer` de Scikit-Learn. Toda la lógica de preprocesamiento + modelo queda encapsulada en **un único objeto**, lo que evita *data leakage* y garantiza el mismo tratamiento de los datos en entrenamiento y en inferencia.

## Dataset

**Titanic** (OpenML, `fetch_openml("titanic", version=1)`), con 1.309 pasajeros y 14 columnas. Una copia queda en `data/titanic.csv` para que el proyecto sea reproducible sin conexión.

- **Target:** `survived` (0 = no sobrevivió, 1 = sobrevivió). Distribución: 61,8% / 38,2%.
- **Problema:** clasificación binaria.

| Tipo | Columnas | Nulos | Tratamiento |
|---|---|---|---|
| Numéricas | `age`, `sibsp`, `parch`, `fare` | `age` (263), `fare` (1) | Imputación por **mediana** → `StandardScaler` |
| Categóricas | `pclass`, `sex`, `embarked` | `embarked` (2) | Imputación por **moda** → `OneHotEncoder(handle_unknown="ignore")` |
| Descartadas | `boat`, `body` | | Fuga de información: solo existen si se conoce el desenlace |
| Descartadas | `name`, `ticket`, `cabin`, `home.dest` | | Texto libre o mayoría de nulos |

> `pclass` se trata como categórica: 1ª, 2ª y 3ª clase son grupos, no una magnitud.

## Arquitectura del pipeline

```
Pipeline
├── preprocessor: ColumnTransformer
│   ├── num: Pipeline [SimpleImputer(median) → StandardScaler]      ← age, sibsp, parch, fare
│   └── cat: Pipeline [SimpleImputer(most_frequent) → OneHotEncoder] ← pclass, sex, embarked
└── classifier: LogisticRegression
```

## Cómo se evita el data leakage

1. Se hace `train_test_split` (80/20, estratificado) **antes** de cualquier `fit`.
2. El `fit` del pipeline se llama solo con `X_train`: medianas, modas, medias y desviaciones se aprenden únicamente del entrenamiento.
3. Sobre `X_test` y los datos nuevos solo se aplica `transform`/`predict`, con los parámetros ya aprendidos.

## Resultados (test, 262 pasajeros)

| Métrica | Valor |
|---|---|
| Accuracy | 0,805 |
| F1 (No sobrevivió) | 0,85 |
| F1 (Sobrevivió) | 0,74 |

## Estructura del repositorio

```
├── README.md
├── requirements.txt
├── data/
│   └── titanic.csv                     # copia local del dataset
├── models/
│   └── pipeline_titanic.joblib         # pipeline entrenado (preprocesador + modelo)
├── notebooks/
│   └── pipeline_preprocesamiento.ipynb # versión explicada paso a paso
└── src/
    └── pipeline.py                     # versión script
```

## Cómo ejecutarlo

```bash
pip install -r requirements.txt

# Opción 1: script
python src/pipeline.py

# Opción 2: notebook
jupyter notebook notebooks/pipeline_preprocesamiento.ipynb
```

## Usar el pipeline guardado

```python
import joblib
import pandas as pd

model = joblib.load("models/pipeline_titanic.joblib")

nuevo = pd.DataFrame([{
    "age": None, "sibsp": 1, "parch": 0, "fare": 80.0,
    "pclass": "1", "sex": "female", "embarked": "X",  # nulo y categoría desconocida
}])
model.predict(nuevo)        # -> array([1])
model.predict_proba(nuevo)  # probabilidades
```

Los datos crudos entran directo al `.predict()`: el pipeline imputa, escala y codifica por sí solo, y gracias a `handle_unknown="ignore"` no falla con categorías nunca vistas.

## Checklist de la práctica

- [x] README con descripción del dataset
- [x] `Pipeline` con más de dos pasos encadenados
- [x] `ColumnTransformer` que separa numéricas y categóricas
- [x] Train/Test split antes de ajustar el preprocesamiento
- [x] `.predict()` funcional sobre datos nuevos
- [x] Exportación del pipeline con `joblib`
